return {
  base00 = '#E8E3E3',
  base01 = '#DED9D9',
  base02 = '#D5D1D1',
  base03 = '#C2BEBE',
  base04 = '#747272',
  base05 = '#747272',
  base06 = '#747272',
  base07 = '#747272',
  base08 = '#b66467',
  base09 = '#d9bc8c',
  base0A = '#d9bc8c',
  base0B = '#8c977d',
  base0C = '#8aa6a2',
  base0D = '#8da3b9',
  base0E = '#a988b0',
  base0F = '#d9bc8c'
}
