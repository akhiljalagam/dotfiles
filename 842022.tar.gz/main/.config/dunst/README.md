<p align="center"><img src="https://raw.githubusercontent.com/lighthaus-theme/dunst/e7f6b633398a1db66e6ff1b0ffbf7c76e672be01/assets/dunst-badge.svg" width="230"><p>


<p align="center">
   <a href="https://www.buymeacoffee.com/asirohi"><img alt="Status" src="https://raw.githubusercontent.com/lighthaus-theme/lighthaus-theme/3cc9fd60c69da89f56721ca9048f38709b3dc878/BuyUsACoffee.svg" width="150" height="23"></a>
</p>

<h2 align="center">Dunst Lighthaus</h2>

A [Lighthaus](https://github.com/lighthaus-theme/lighthaus) theme for [Dunst](https://github.com/dunst-project/dunst).

### Screenshots

<p align="center"><img src="https://github.com/lighthaus-theme/dunst/blob/master/assets/dunst-01.png?raw=true"><p>

Font used in the screenshots: [Source Code Pro for Powerline](https://github.com/powerline/fonts/tree/master/SourceCodePro)

### Contributing

Check out [CONTRIBUTING](https://github.com/lighthaus-theme/lighthaus/blob/master/CONTRIBUTING.md). 

Pull Request Template can be found [here](https://github.com/lighthaus-theme/lighthaus/blob/master/PULL_REQUEST_TEMPLATE.md) and Issues and Bugs Template [here](https://github.com/lighthaus-theme/lighthaus/blob/master/ISSUE_TEMPLATE.md).

